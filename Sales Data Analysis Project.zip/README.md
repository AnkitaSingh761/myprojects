
# Sales Data Analysis

**Role:** Data Analyst Intern  
**Tools:** Excel, Pivot Tables, Charts  
**Objective:** Analyze sales data to find top products, monthly trends, and key insights for business decisions.

## Key Findings
- Product A is the top-selling product  
- Region East generates highest revenue  
- Sales peak observed in December  
- Top 10% customers contribute 50% of revenue

## Folder Structure
- data/: Contains sales_data.xlsx  
- visualizations/: Optional screenshots of charts  
